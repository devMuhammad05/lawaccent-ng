<section class="faq-section">
    <div class="container">
        @include('web.partials.faq-accordion')
    </div>
</section>
