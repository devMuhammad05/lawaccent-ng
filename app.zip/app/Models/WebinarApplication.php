<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WebinarApplication extends Model
{
    protected $fillable = [
        'name',
        'email',
        'phone_number',
        'question',
        'type',
        'is_read',
    ];

    public function scopeUnread($query)
    {
        return $query->where('is_read', false);
    }

    public function markAsRead()
    {
        $this->is_read = true;
        $this->save();
    }
}
