<?php

namespace App\Livewire;

use Livewire\Component;

class PodcastMedia extends Component
{
    public function render()
    {
        return view('livewire.podcast-media');
    }
}
