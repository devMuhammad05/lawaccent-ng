<?php

namespace App\Livewire;

use Livewire\Component;

class VideoMedia extends Component
{
    public function render()
    {
        return view('livewire.video-media');
    }
}
